

<?php
    $pageName = "guitar shop";
    
    include "./views/header.php";

    echo ("<a href='./product_catalog'>Product Catalog</a><br>");
    echo ("<a href='./product_manager'>Product Manager</a><br>");
    echo ("<a href='./employee'>Employees</a>");
    
    include "./views/footer.php";
?>
    
