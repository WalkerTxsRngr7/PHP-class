<form action="index.php" method="post" enctype="multipart/form-data">

    <p>First Name: </p>
    <input type="text" name="firstName">

    <p>Last Name: </p>
    <input type="text" name="lastName">

    <p>Photo: </p>
    <input type="file" name="photo" style="margin:15px 0px;">

    <input type="submit" value="Add Employee">
    <input type="hidden" name="added" value="true">
    

</form>

