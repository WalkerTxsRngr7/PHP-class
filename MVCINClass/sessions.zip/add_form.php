<form action="index.php" method="post">

    <p>Name: </p>
    <input type="text" name="addname">

    <p>Username: </p>
    <input type="text" name="addusername">

    <p>Password: </p>
    <input type="text" name="addpassword">

    <input type="submit" value="Add Employee">
    <input type="hidden" name="added" value="true">
    

</form>

