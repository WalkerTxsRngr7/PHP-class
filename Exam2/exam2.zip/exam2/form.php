<h1>Price Quote</h1>
<form action="./index.php" method="get">
  <label for="salePrice">Sales Price</label>
  <input type="text" name="salePrice"><br><br>
  <label for="discountPercent">Discount %</label>
  <input type="text" name="discountPercent"><br><br>
  <input type="submit" name="submit" value="Submit">
</form>
