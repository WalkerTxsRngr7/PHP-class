

<?php
    include "./models/database.php";
    include "./views/header.php";

    
    //print_r($aryCat);
    include "./models/categories_db.php";
    include "./models/products_db.php";
    include "./views/category_list.php";

    $catID = filter_input(INPUT_GET, 'cat');

    if ($catID == NULL){
        $catID = 1;
    }
    
    include "./views/product_list.php";


    include "./views/footer.php";
?>
    
