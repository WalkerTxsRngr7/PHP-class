<form id='loginForm' action='' method='post'>
    <div class="form-group row">
        <label for="inputEmail3" class="col-sm-2 col-form-label">Username</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" placeholder="Username" name='username'>
        </div>
    </div>
    <div class="form-group row">
        <label for="inputPassword3" class="col-sm-2 col-form-label">Password</label>
        <div class="col-sm-10">
            <input type="password" class="form-control" id="inputPassword3" placeholder="Password" name='password'>
        </div>
    </div>
    <button type="submit" class="btn btn-outline-light rounded-0">Login</button>
</form>