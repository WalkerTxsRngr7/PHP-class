<?php

$productID = filter_input(INPUT_GET, "productID");
$productName = filter_input(INPUT_GET, "productName");
$qty = filter_input(INPUT_GET, "qty");
$order = filter_input(INPUT_GET, "order");
$customerName = filter_input(INPUT_GET, "customerName");
?>