<?php
session_start();
$title = "Home";
$headTitle = "\$store";
include "../views/header.php";


include "../product/product_list.php";

    
include "../views/footer.php";
?>