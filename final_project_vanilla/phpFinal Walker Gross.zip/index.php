<?php
header("Location: ./product/index.php");
?>