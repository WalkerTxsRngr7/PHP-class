<?php

    $userName = "mgs_user";
    $password = "pa55word";
    $host = "localhost";
    $db_name = "my_guitar_shop1";
    
    $db = mysqli_connect($host, $userName, $password, $db_name);