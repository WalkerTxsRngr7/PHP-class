<!-- form for them to input their info -->
<form action="" method="get"> 
    <input type="text" name="name" placeholder="Name">
	<input type="text" name="phone" placeholder="Phone Number">
    <input type="text" name="email" placeholder="Email">
	<input type="submit" value="Subscribe">
</form>